package com.example.save4u.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

// Response data class (matches Django JSON response)
data class UploadResponse(
    val message: String,
    val parsedData: List<String>?
)

interface ApiService {
    @Multipart
    @POST("upload_statement/")
    fun uploadPdf(
        @Part pdf: MultipartBody.Part,
        @Part("user_id") userId: RequestBody
    ): Call<UploadResponse>
}

object RetrofitClient {
    private const val BASE_URL = "http://10.0.2.2:8000/api/"
    // For emulator: 10.0.2.2.
    // For real device on same Wi-Fi: use your PC's LAN IP, like http://192.168.X.X:8000/api/

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
