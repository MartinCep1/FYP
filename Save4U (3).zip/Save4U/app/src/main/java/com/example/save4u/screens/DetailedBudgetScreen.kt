package com.example.save4u.screens

// ----------------- Imports -----------------
import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.google.accompanist.flowlayout.FlowRow // make sure you have the Accompanist dependency
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID
import kotlin.random.Random

// ----------------- Data Classes -----------------

data class MyTransaction(
    val id: String = UUID.randomUUID().toString(),
    val date: String? = null,
    val details: String? = null,
    val amount: Double = 0.0
)

data class BudgetCategory(
    val id: String = UUID.randomUUID().toString(),
    val name: String = ""
)

// SubTransaction, referencing an original “mini” transaction
data class SubTransaction(
    val id: String = UUID.randomUUID().toString(),
    val originalId: String = "",
    val details: String = "",
    val amount: Double = 0.0
)

// A single grouped transaction doc in Firestore
data class GroupedTransaction(
    val id: String = UUID.randomUUID().toString(),
    val groupName: String = "",
    val categoryName: String = "Unassigned",
    val subs: List<SubTransaction> = emptyList()
)

// ----------------- DetailedBudgetScreen -----------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailedBudgetScreen(
    navController: NavController,
    textStyle: TextStyle
) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val userId = auth.currentUser?.uid

    // 1) “Ungrouped” transactions from your main “transactions” DB
    var ungroupedTxns by remember { mutableStateOf<List<MyTransaction>>(emptyList()) }
    var selectedTxIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    // 2) Budget categories
    var categories by remember { mutableStateOf<List<BudgetCategory>>(emptyList()) }

    // 3) Grouped transactions
    var groupedTxs by remember { mutableStateOf<List<GroupedTransaction>>(emptyList()) }

    // For expansions
    var expandedGroupId by remember { mutableStateOf<String?>(null) }

    // For dialog states
    var showCatDialog by remember { mutableStateOf(false) }
    var showGroupDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    // ----------------- Firestore Loading -----------------

    // Load ungrouped transactions
    LaunchedEffect(userId) {
        if (userId != null) {
            val snap = db.collection("users")
                .document(userId)
                .collection("transactions")
                .get()
                .await()

            val loaded = snap.documents.mapNotNull { doc ->
                val tid = doc.id
                val t = doc.toObject(MyTransaction::class.java)
                // Keep doc.id in the object
                t?.copy(id = tid)
            }
            // We treat these as “ungrouped” for the table
            ungroupedTxns = loaded
        }
    }

    // Load categories from "users/{uid}/budget_categories"
    LaunchedEffect(userId) {
        if (userId != null) {
            val snapCat = db.collection("users")
                .document(userId)
                .collection("budget_categories")
                .get()
                .await()

            val catDocs = snapCat.documents.mapNotNull { doc ->
                val bc = doc.toObject(BudgetCategory::class.java)
                bc?.copy(id = doc.id)
            }
            categories = catDocs
        }
    }

    // Load grouped transactions from "users/{uid}/grouped_txns"
    LaunchedEffect(userId) {
        if (userId != null) {
            val snapGrp = db.collection("users")
                .document(userId)
                .collection("grouped_txns")
                .get()
                .await()

            val grpDocs = snapGrp.documents.mapNotNull { doc ->
                val gx = doc.toObject(GroupedTransaction::class.java)
                gx?.copy(id = doc.id)
            }
            groupedTxs = grpDocs
        }
    }

    // Compose UI
    Surface(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Column {
            Text("Detailed Budget (Table Style)", style = textStyle.copy(fontSize = 24.sp))
            Spacer(Modifier.height(8.dp))

            // A row (FlowRow) of main actions
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { showCatDialog = true }) {
                    Text("Create Category", style = textStyle)
                }
                OutlinedButton(onClick = {
                    // If user selected some transactions from ungrouped
                    showGroupDialog = true
                }) {
                    Text("Group Selected Txns", style = textStyle)
                }
                OutlinedButton(onClick = {
                    // Auto-group
                    scope.launch {
                        autoGroupUngroupedTxns(
                            ungrouped = ungroupedTxns,
                            db = db,
                            userId = userId
                        ) { newGroups, removedIds ->
                            // 1) Add the newly created grouped docs to groupedTxs
                            groupedTxs = groupedTxs + newGroups
                            // 2) Remove them from the ungroupedTxns
                            ungroupedTxns = ungroupedTxns.filter { !removedIds.contains(it.id) }
                        }
                    }
                }) {
                    Text("Auto Sort by Name", style = textStyle)
                }
            }

            Spacer(Modifier.height(16.dp))

            // Section A: “Ungrouped” transactions list with checkboxes
            Text("Ungrouped Transactions:", style = textStyle.copy(fontSize = 18.sp))
            if (ungroupedTxns.isEmpty()) {
                Text("No ungrouped transactions found", style = textStyle)
            } else {
                LazyColumn {
                    itemsIndexed(ungroupedTxns) { _, txn ->
                        UngroupedTxnRow(
                            transaction = txn,
                            textStyle = textStyle,
                            isSelected = selectedTxIds.contains(txn.id),
                            onSelectToggle = { tid ->
                                selectedTxIds = if (selectedTxIds.contains(tid)) {
                                    selectedTxIds - tid
                                } else {
                                    selectedTxIds + tid
                                }
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // Section B: Show categories + grouped transactions
            Text("Category Table:", style = textStyle.copy(fontSize = 18.sp))
            if (categories.isEmpty()) {
                Text("No categories. Please create one!", style = textStyle)
            } else {
                // For each category, show the groupedTxns that match
                categories.forEach { cat ->
                    val catGroups = groupedTxs.filter { it.categoryName == cat.name }
                    CategorySectionTable(
                        category = cat,
                        textStyle = textStyle,
                        groupList = catGroups,
                        expandedGroupId = expandedGroupId,
                        onExpandToggle = { grpId ->
                            expandedGroupId = if (expandedGroupId == grpId) null else grpId
                        },
                        onRemoveGroup = { group ->
                            userId?.let { uid ->
                                db.collection("users").document(uid)
                                    .collection("grouped_txns")
                                    .document(group.id)
                                    .delete()
                            }
                            groupedTxs = groupedTxs.filterNot { it.id == group.id }
                        }
                    )
                }

                // Also show any group that has categoryName = "Unassigned"
                val unassigned = groupedTxs.filter { it.categoryName == "Unassigned" }
                if (unassigned.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Unassigned Groups:", style = textStyle.copy(fontSize = 18.sp))
                    unassigned.forEach { grp ->
                        GroupedTableRow(
                            group = grp,
                            textStyle = textStyle,
                            expanded = (expandedGroupId == grp.id),
                            onExpandToggle = {
                                expandedGroupId =
                                    if (expandedGroupId == grp.id) null else grp.id
                            },
                            onRemoveGroup = {
                                userId?.let { uid ->
                                    db.collection("users").document(uid)
                                        .collection("grouped_txns")
                                        .document(grp.id)
                                        .delete()
                                }
                                groupedTxs = groupedTxs.filterNot { it.id == grp.id }
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            OutlinedButton(onClick = { navController.popBackStack() }) {
                Text("Back to Budgeting", style = textStyle)
            }
        }
    }

    // Dialog for creating a new category
    if (showCatDialog) {
        CreateCategoryDialog(
            textStyle = textStyle,
            onDismiss = { showCatDialog = false },
            onCreate = { catName ->
                val uid = userId ?: return@CreateCategoryDialog
                val docRef = db.collection("users").document(uid)
                    .collection("budget_categories")
                    .document()
                val catObj = BudgetCategory(id = docRef.id, name = catName)
                docRef.set(catObj)
                categories = categories + catObj
            }
        )
    }

    // Dialog for grouping selected transactions
    if (showGroupDialog) {
        if (selectedTxIds.isEmpty()) {
            // If user didn't select anything, just show a warning
            AlertDialog(
                onDismissRequest = { showGroupDialog = false },
                title = { Text("No transactions selected", style = textStyle) },
                text = { Text("Please select some ungrouped transactions first.", style = textStyle) },
                confirmButton = {
                    OutlinedButton(onClick = { showGroupDialog = false }) {
                        Text("OK", style = textStyle)
                    }
                }
            )
        } else {
            InsertGroupedDialog(
                textStyle = textStyle,
                categories = categories,
                selectedTransactions = ungroupedTxns.filter { selectedTxIds.contains(it.id) },
                onDismiss = { showGroupDialog = false },
                onSave = { groupName, catName ->
                    val subs = ungroupedTxns.filter { selectedTxIds.contains(it.id) }.map { txn ->
                        SubTransaction(
                            id = txn.id,
                            originalId = txn.id,
                            details = txn.details ?: "No details",
                            amount = txn.amount
                        )
                    }
                    val uid = userId ?: return@InsertGroupedDialog
                    val docRef = db.collection("users").document(uid)
                        .collection("grouped_txns")
                        .document()
                    val newGrp = GroupedTransaction(
                        id = docRef.id,
                        groupName = groupName,
                        categoryName = catName,
                        subs = subs
                    )
                    docRef.set(newGrp)

                    // Update local state
                    groupedTxs = groupedTxs + newGrp

                    // remove from main transactions
                    subs.forEach { sub ->
                        db.collection("users").document(uid)
                            .collection("transactions")
                            .document(sub.originalId)
                            .delete()
                    }
                    ungroupedTxns = ungroupedTxns.filter { !selectedTxIds.contains(it.id) }
                    selectedTxIds = emptySet()

                    showGroupDialog = false
                }
            )
        }
    }
}

//-------------------------------------
// The auto-group logic lumps ungrouped transactions
// with the same "cleaned" name into a single group,
// then removes them from ungrouped, sets "Unassigned" category
//-------------------------------------
suspend fun autoGroupUngroupedTxns(
    ungrouped: List<MyTransaction>,
    db: FirebaseFirestore,
    userId: String?,
    onResult: (newGroups: List<GroupedTransaction>, removedIds: Set<String>) -> Unit
) {
    if (userId == null || ungrouped.isEmpty()) {
        onResult(emptyList(), emptySet())
        return
    }

    // We'll group them by normalized details
    val groupedMap = mutableMapOf<String, MutableList<MyTransaction>>()
    val patternVdp = Regex("^VDP\\s+", RegexOption.IGNORE_CASE)

    for (txn in ungrouped) {
        val det = txn.details?.trim()?.uppercase() ?: ""
        if (det.isBlank()) {
            groupedMap.getOrPut("Miscellaneous") { mutableListOf() }.add(txn)
        } else {
            val cleaned = det.replace(patternVdp, "").trim()
            if (cleaned.isEmpty()) {
                groupedMap.getOrPut("Miscellaneous") { mutableListOf() }.add(txn)
            } else {
                groupedMap.getOrPut(cleaned) { mutableListOf() }.add(txn)
            }
        }
    }

    val newGroups = mutableListOf<GroupedTransaction>()
    val removedIds = mutableSetOf<String>()

    for ((groupName, txList) in groupedMap) {
        val subList = txList.map { tx ->
            SubTransaction(
                id = tx.id,
                originalId = tx.id,
                details = tx.details ?: "No details",
                amount = tx.amount
            )
        }
        val docRef = db.collection("users").document(userId)
            .collection("grouped_txns")
            .document()

        val groupedObj = GroupedTransaction(
            id = docRef.id,
            groupName = groupName,
            categoryName = "Unassigned", // user can re-assign later
            subs = subList
        )
        docRef.set(groupedObj)
        newGroups.add(groupedObj)

        // remove them from main "transactions"
        for (tx in txList) {
            db.collection("users").document(userId)
                .collection("transactions")
                .document(tx.id)
                .delete()
            removedIds.add(tx.id)
        }
    }

    onResult(newGroups, removedIds)
}

//-------------------------------------
// A single row for ungrouped transaction
//-------------------------------------
@Composable
fun UngroupedTxnRow(
    transaction: MyTransaction,
    textStyle: TextStyle,
    isSelected: Boolean,
    onSelectToggle: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectToggle(transaction.id) }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            val dateStr = transaction.date ?: ""
            val detailStr = transaction.details ?: ""
            Text(dateStr, style = textStyle)
            Text(detailStr, style = textStyle)
        }
        Row {
            Text("€%.2f".format(transaction.amount), style = textStyle)
            Spacer(Modifier.width(16.dp))
            // A simple checkbox representation
            Text(if (isSelected) "[X]" else "[ ]", style = textStyle)
        }
    }
}

//-------------------------------------
// CategorySectionTable: show groupList for each category
//-------------------------------------
@Composable
fun CategorySectionTable(
    category: BudgetCategory,
    textStyle: TextStyle,
    groupList: List<GroupedTransaction>,
    expandedGroupId: String?,
    onExpandToggle: (String) -> Unit,
    onRemoveGroup: (GroupedTransaction) -> Unit
) {
    val totalCatAmount = groupList.sumOf { grp -> grp.subs.sumOf { it.amount } }
    Spacer(Modifier.height(8.dp))
    Text("${category.name} (Total: €%.2f)".format(totalCatAmount), style = textStyle.copy(fontSize = 18.sp))
    if (groupList.isEmpty()) {
        Text("No grouped items under '${category.name}' yet.", style = textStyle)
        return
    }
    groupList.forEach { grp ->
        GroupedTableRow(
            group = grp,
            textStyle = textStyle,
            expanded = (expandedGroupId == grp.id),
            onExpandToggle = { onExpandToggle(grp.id) },
            onRemoveGroup = { onRemoveGroup(grp) }
        )
    }
}

//-------------------------------------
// A single group row
//-------------------------------------
@Composable
fun GroupedTableRow(
    group: GroupedTransaction,
    textStyle: TextStyle,
    expanded: Boolean,
    onExpandToggle: () -> Unit,
    onRemoveGroup: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onExpandToggle() },
        shape = RoundedCornerShape(6.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        val total = group.subs.sumOf { it.amount }
        Column(modifier = Modifier.padding(8.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(group.groupName, style = textStyle)
                Text("€%.2f".format(total), style = textStyle)
            }
            Text("Category: ${group.categoryName}", style = textStyle.copy(fontSize = 14.sp, color = Color.Gray))

            if (expanded) {
                Spacer(Modifier.height(8.dp))
                group.subs.forEach { sub ->
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 2.dp)
                    ) {
                        Text(sub.details, style = textStyle.copy(fontSize = 14.sp))
                        Text("€%.2f".format(sub.amount), style = textStyle.copy(fontSize = 14.sp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onRemoveGroup) {
                    Text("Delete Group", style = textStyle)
                }
            }
        }
    }
}

//-------------------------------------
// Dialog for creating a new category
//-------------------------------------
@Composable
fun CreateCategoryDialog(
    textStyle: TextStyle,
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var catName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Category", style = textStyle) },
        text = {
            Column {
                Text("Category Name:", style = textStyle)
                Spacer(Modifier.height(4.dp))
                BasicTextField(
                    value = catName,
                    onValueChange = { catName = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.LightGray)
                        .padding(8.dp)
                )
            }
        },
        confirmButton = {
            OutlinedButton(onClick = {
                if (catName.isNotEmpty()) onCreate(catName)
                onDismiss()
            }) {
                Text("Create", style = textStyle)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", style = textStyle)
            }
        }
    )
}

//-------------------------------------
// Dialog for grouping selected transactions
//-------------------------------------
@Composable
fun InsertGroupedDialog(
    textStyle: TextStyle,
    categories: List<BudgetCategory>,
    selectedTransactions: List<MyTransaction>,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var groupName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Group Selected Transactions", style = textStyle) },
        text = {
            Column {
                Text("Group Name:", style = textStyle)
                Spacer(Modifier.height(4.dp))
                BasicTextField(
                    value = groupName,
                    onValueChange = { groupName = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.LightGray)
                        .padding(8.dp)
                )

                Spacer(Modifier.height(8.dp))
                Text("Pick Category:", style = textStyle)
                if (categories.isEmpty()) {
                    Text("No categories. Create one first!", style = textStyle)
                } else {
                    // show a simple radio for each category
                    categories.forEach { cat ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCategory = cat.name }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = (selectedCategory == cat.name),
                                onClick = { selectedCategory = cat.name }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(cat.name, style = textStyle)
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text("Selected Transactions:", style = textStyle)
                selectedTransactions.forEach { t ->
                    val detailStr = t.details ?: "No details"
                    Text("- $detailStr (€%.2f)".format(t.amount), style = textStyle.copy(fontSize = 14.sp))
                }
            }
        },
        confirmButton = {
            OutlinedButton(onClick = {
                if (groupName.isNotEmpty() && selectedCategory != null) {
                    onSave(groupName, selectedCategory!!)
                }
            }) {
                Text("Create Group", style = textStyle)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", style = textStyle)
            }
        }
    )
}
