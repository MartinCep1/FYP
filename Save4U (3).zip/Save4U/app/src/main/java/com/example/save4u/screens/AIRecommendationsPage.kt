package com.example.save4u.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

data class ShoppingRecommendation(
    val title: String,
    val storeName: String,
    val price: Double,
    val link: String
)

suspend fun getDealsFromFirebase(userId: String): JSONObject? {
    // Use 10.0.2.2 if running on the Android emulator so that the local server is reachable.
    val url = "http://10.0.2.2:8000/api/find_coupons_from_firebase/"
    val client = OkHttpClient()
    val jsonBody = """{"user_id": "$userId"}"""
    val reqBody = jsonBody.toRequestBody("application/json".toMediaTypeOrNull())
    val request = Request.Builder()
        .url(url)
        .post(reqBody)
        .build()

    return withContext(Dispatchers.IO) {
        try {
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                println("DEBUG: Response code = ${response.code}")
                return@withContext null
            }
            val bodyStr = response.body?.string()
            println("DEBUG: Raw JSON from server -> $bodyStr")
            if (bodyStr != null) JSONObject(bodyStr) else null
        } catch (e: Exception) {
            println("DEBUG: Exception in getDealsFromFirebase: ${e.stackTraceToString()}")
            null
        }
    }
}

@Composable
fun AIRecommendationsPage(navController: NavController, textStyle: TextStyle) {
    val scope = rememberCoroutineScope()
    var statusMessage by remember { mutableStateOf("Idle") }
    var topMerchants by remember { mutableStateOf<List<String>>(emptyList()) }
    var dealsMap by remember { mutableStateOf<Map<String, List<ShoppingRecommendation>>>(emptyMap()) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Button(
                onClick = {
                    println("DEBUG: Find Coupons button pressed.")
                    scope.launch {
                        statusMessage = "Fetching deals..."
                        val result = getDealsFromFirebase("TEST_USER_ID")
                        if (result == null) {
                            statusMessage = "Error: No response from server."
                        } else {
                            // Parse top_merchants array
                            val merchantsArr = result.optJSONArray("top_merchants")
                            val merchantsList = mutableListOf<String>()
                            if (merchantsArr != null) {
                                for (i in 0 until merchantsArr.length()) {
                                    merchantsList.add(merchantsArr.getString(i))
                                }
                            }
                            topMerchants = merchantsList

                            // Parse deals object
                            val dealsObj = result.optJSONObject("deals")
                            val newDealsMap = mutableMapOf<String, List<ShoppingRecommendation>>()
                            if (dealsObj != null) {
                                val merchantKeys = dealsObj.keys()
                                while (merchantKeys.hasNext()) {
                                    val merchant = merchantKeys.next()
                                    val arr = dealsObj.optJSONArray(merchant)
                                    val recs = mutableListOf<ShoppingRecommendation>()
                                    if (arr != null) {
                                        for (j in 0 until arr.length()) {
                                            val item = arr.optJSONObject(j)
                                            if (item != null) {
                                                recs.add(
                                                    ShoppingRecommendation(
                                                        title = "Deal for ${item.optString("merchant")}",
                                                        storeName = item.optString("merchant"),
                                                        price = 9.99, // Adjust if discount is numeric
                                                        link = ""     // We're ignoring links
                                                    )
                                                )
                                            }
                                        }
                                    }
                                    newDealsMap[merchant] = recs
                                }
                            }
                            dealsMap = newDealsMap
                            statusMessage = "Deals fetched."
                        }
                    }
                }
            ) {
                Text("Find Coupons", style = textStyle)
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Status: $statusMessage", style = textStyle)
            Spacer(modifier = Modifier.height(16.dp))
            if (topMerchants.isNotEmpty()) {
                Text("Top Merchants:", style = textStyle)
                topMerchants.forEach { merchant ->
                    Text(merchant, style = textStyle)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            if (dealsMap.isNotEmpty()) {
                Text("Deals found:", style = textStyle)
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    dealsMap.forEach { (merchant, recs) ->
                        item {
                            Text("Merchant: $merchant", style = textStyle)
                        }
                        items(recs) { rec ->
                            RecommendationItem(rec, textStyle)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecommendationItem(item: ShoppingRecommendation, textStyle: TextStyle) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(item.title, style = textStyle)
            Text("Store: ${item.storeName}", style = textStyle)
            Text("Price: €%.2f".format(item.price), style = textStyle)
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { /* Handle link action if needed */ }) {
                Text("View Deal", style = textStyle)
            }
        }
    }
}
