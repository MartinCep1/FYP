package com.example.save4u.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random
import androidx.compose.ui.viewinterop.AndroidView
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.utils.ColorTemplate

//-------------------------------------
// DATA CLASSES
//-------------------------------------

data class Transaction(
    var date: String? = null,
    var details: String? = null,
    var amount: Double = 0.0,
    var balance: Double? = null,
    var category: String = "Uncategorized",
    var id: String = UUID.randomUUID().toString()
)

data class Goal(
    var title: String = "",
    var targetAmount: Double = 0.0,
    var currentAmount: Double = 0.0,
    var id: String = UUID.randomUUID().toString()
)

//-------------------------------------
// MAIN COMPOSABLE: BudgetingPage
//-------------------------------------
@Composable
fun BudgetingPage(
    navController: NavController,
    textStyle: TextStyle
) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val userId = auth.currentUser?.uid

    // State for transactions
    var allTransactions by remember { mutableStateOf<List<Transaction>>(emptyList()) }
    var filteredTransactions by remember { mutableStateOf<List<Transaction>>(emptyList()) }

    // Show only 20 items
    var shownCount by remember { mutableStateOf(20) }
    var selectedRange by remember { mutableStateOf("1M") }
    var expandedTransactionId by remember { mutableStateOf<String?>(null) }

    // State for goals
    var goals by remember { mutableStateOf<List<Goal>>(emptyList()) }

    // "Add Goal" dialog
    var showDialog by remember { mutableStateOf(false) }

    // Load Firestore transactions
    LaunchedEffect(userId) {
        if (userId != null) {
            val snapshot = db.collection("users")
                .document(userId)
                .collection("transactions")
                .get()
                .await()

            val txns = snapshot.documents.mapNotNull { doc ->
                doc.toObject(Transaction::class.java)?.copy(id = doc.id)
            }
            allTransactions = txns
            filteredTransactions = filterTransactions(txns, selectedRange)
        }
    }

    // Load Firestore goals
    LaunchedEffect(userId) {
        if (userId != null) {
            val snapGoals = db.collection("users")
                .document(userId)
                .collection("goals")
                .get()
                .await()

            val loadedGoals = snapGoals.documents.mapNotNull { doc ->
                doc.toObject(Goal::class.java)?.copy(id = doc.id)
            }
            goals = loadedGoals
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        // If there's no data at all (no transactions, no goals), let's show a fallback
        val noDataFound = allTransactions.isEmpty() && goals.isEmpty()

        if (noDataFound) {
            // Show a placeholder message if everything is empty
            Column(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("No data found in your Firestore. Please add transactions or goals!", style = textStyle)
            }
        } else {
            // Otherwise we proceed with the main UI
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1) Range Filter + Summaries + Pie
                item {
                    RangeFilterAndSummary(
                        textStyle = textStyle,
                        selectedRange = selectedRange,
                        onRangeSelected = { newRange ->
                            selectedRange = newRange
                            shownCount = 20
                            filteredTransactions = if (newRange == "ALL") {
                                allTransactions
                            } else {
                                filterTransactions(allTransactions, newRange)
                            }
                        },
                        filteredTransactions = filteredTransactions
                    )
                }

                // 2) Spending Insights bar chart
                item {
                    SpendingInsightsSection(textStyle, filteredTransactions)
                }

                // 3) Net worth line chart
                item {
                    NetWorthSection(textStyle, filteredTransactions)
                }

                // 4) Financial Goals
                item {
                    FinancialGoalsSection(
                        textStyle = textStyle,
                        goals = goals,
                        onAddProgress = { g, addAmt ->
                            val newVal = g.currentAmount + addAmt
                            val updated = g.copy(currentAmount = newVal)
                            goals = goals.map { if (it.id == g.id) updated else it }
                            // Update Firestore
                            userId?.let { uid ->
                                db.collection("users").document(uid)
                                    .collection("goals")
                                    .document(g.id)
                                    .update("currentAmount", newVal)
                            }
                        }
                    )
                }

                // 5) Budgeting
                item {
                    BudgetingSection(navController, textStyle)
                }

                // 6) monthly spending
                item {
                    MonthlySpendingBoxes(filteredTransactions, textStyle)
                }

                // 7) transaction list
                item {
                    TransactionListSection(
                        textStyle = textStyle,
                        filteredTransactions = filteredTransactions,
                        shownCount = shownCount,
                        expandedTransactionId = expandedTransactionId,
                        onExpandToggle = { tid ->
                            expandedTransactionId = if (expandedTransactionId == tid) null else tid
                        },
                        onShowMore = { shownCount += 20 },
                        onDeleteTxn = { toDelete ->
                            filteredTransactions = filteredTransactions.filter { it.id != toDelete.id }
                            allTransactions = allTransactions.filter { it.id != toDelete.id }
                            userId?.let { uid ->
                                db.collection("users").document(uid)
                                    .collection("transactions")
                                    .document(toDelete.id)
                                    .delete()
                            }
                        },
                        onEditTxn = { toEdit ->
                            val updated = toEdit.copy(amount = toEdit.amount + 10)
                            filteredTransactions = filteredTransactions.map {
                                if (it.id == toEdit.id) updated else it
                            }
                            allTransactions = allTransactions.map {
                                if (it.id == toEdit.id) updated else it
                            }
                            userId?.let { uid ->
                                db.collection("users").document(uid)
                                    .collection("transactions")
                                    .document(toEdit.id)
                                    .update("amount", updated.amount)
                            }
                        },
                        onCategoryChange = { toEdit, newCat ->
                            val updated = toEdit.copy(category = newCat)
                            filteredTransactions = filteredTransactions.map {
                                if (it.id == toEdit.id) updated else it
                            }
                            allTransactions = allTransactions.map {
                                if (it.id == toEdit.id) updated else it
                            }
                            userId?.let { uid ->
                                db.collection("users").document(uid)
                                    .collection("transactions")
                                    .document(toEdit.id)
                                    .update("category", newCat)
                            }
                        }
                    )
                }

                // 8) Buttons for "Add a new goal", "Deals/Recs"
                item {
                    OutlinedButton(onClick = { showDialog = true }) {
                        Text("Add a New Goal", style = textStyle)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        // navController.navigate("DealsOrRecScreen")
                    }) {
                        Text("View Deals & Recommendations", style = textStyle)
                    }
                }
            }
        }
    }

    // Show dialog to add a new goal
    if (showDialog) {
        AddGoalDialog(
            onDismiss = { showDialog = false },
            onAddGoal = { newGoalTitle, newGoalTarget ->
                // create new goal
                val uid = userId ?: return@AddGoalDialog
                val docRef = FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(uid)
                    .collection("goals")
                    .document()
                val g = Goal(title = newGoalTitle, targetAmount = newGoalTarget, currentAmount = 0.0, id = docRef.id)
                docRef.set(g)
                // update local
                goals = goals + g
            },
            textStyle = textStyle
        )
    }
}

//-------------------------------------
//  RangeFilterAndSummary
//-------------------------------------
@Composable
fun RangeFilterAndSummary(
    textStyle: TextStyle,
    selectedRange: String,
    onRangeSelected: (String) -> Unit,
    filteredTransactions: List<Transaction>
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Budgeting Plans", style = textStyle.copy(fontSize = 26.sp), color = MaterialTheme.colorScheme.primary)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ALL", "1M", "3M", "6M", "1Y").forEach { range ->
                OutlinedButton(onClick = { onRangeSelected(range) }) {
                    Text(
                        range,
                        color = if (range == selectedRange) MaterialTheme.colorScheme.primary else Color.Black
                    )
                }
            }
        }

        if (filteredTransactions.isEmpty()) {
            Text("No transactions found for this date range.", style = textStyle)
        } else {
            val totalIncome = filteredTransactions.filter { it.amount > 0.0 }.sumOf { it.amount }
            val totalExpenses = filteredTransactions.filter { it.amount < 0.0 }.sumOf { it.amount }

            Text("Income: €%.2f".format(totalIncome), style = textStyle)
            Text("Expenses: €%.2f".format(totalExpenses), style = textStyle)

            Box(modifier = Modifier.height(200.dp)) {
                MPAndroidPieChart(
                    income = totalIncome.toFloat(),
                    expenses = (-totalExpenses).toFloat()
                )
            }
        }
    }
}

//-------------------------------------
//  SpendingInsightsSection
//-------------------------------------
data class MonthEarnedSpent(
    val monthLabel: String,
    val earned: Float,
    val spent: Float
)

fun computeEarnedSpentPerMonth(transactions: List<Transaction>): List<MonthEarnedSpent> {
    val grouped = transactions.groupBy { it.toYearMonthString() }
    val items = mutableListOf<MonthEarnedSpent>()
    for ((month, txns) in grouped) {
        val earnedSum = txns.filter { it.amount > 0.0 }.sumOf { it.amount }.toFloat()
        val spentSum = txns.filter { it.amount < 0.0 }.sumOf { kotlin.math.abs(it.amount) }.toFloat()
        items.add(MonthEarnedSpent(month, earnedSum, spentSum))
    }
    return items.sortedBy { it.monthLabel }
}

@Composable
fun SpendingInsightsSection(
    textStyle: TextStyle,
    filteredTransactions: List<Transaction>
) {
    val monthData = remember(filteredTransactions) {
        computeEarnedSpentPerMonth(filteredTransactions)
    }

    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Spending Insights", style = textStyle.copy(fontSize = 20.sp), color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            if (monthData.isEmpty()) {
                Text("No monthly Earned/Spent data yet.", style = textStyle)
            } else {
                Text("Monthly Earned vs Spent", style = textStyle)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    MPAndroidBarChartReal(monthData)
                }
            }
        }
    }
}

@SuppressLint("NewApi")
@Composable
fun MPAndroidBarChartReal(monthData: List<MonthEarnedSpent>) {
    val context = LocalContext.current
    AndroidView(
        factory = {
            BarChart(context).apply {
                description.isEnabled = false
                setDrawGridBackground(false)
                setPinchZoom(false)
                axisLeft.setDrawGridLines(false)
                xAxis.setDrawGridLines(false)
            }
        },
        update = update@{ barChart ->
            if (monthData.isEmpty()) {
                barChart.data = null
                barChart.invalidate()
                return@update
            }

            val entriesEarned = mutableListOf<BarEntry>()
            val entriesSpent = mutableListOf<BarEntry>()
            monthData.forEachIndexed { index, item ->
                entriesEarned.add(BarEntry(index.toFloat(), item.earned))
                entriesSpent.add(BarEntry(index.toFloat(), item.spent))
            }

            val setEarned = BarDataSet(entriesEarned, "Earned").apply {
                color = ColorTemplate.rgb("#7B1FA2")
            }
            val setSpent = BarDataSet(entriesSpent, "Spent").apply {
                color = ColorTemplate.rgb("#D81B60")
            }
            val barData = BarData(setEarned, setSpent)
            barData.barWidth = 0.3f

            barChart.data = barData
            barChart.xAxis.axisMinimum = -0.5f
            barChart.xAxis.axisMaximum = (monthData.size - 0.5f)
            barChart.groupBars(0f, 0.4f, 0f)
            barChart.invalidate()
        },
        modifier = Modifier.fillMaxSize()
    )
}

//-------------------------------------
//  NetWorthSection
//-------------------------------------
data class DateValuePoint(val dateMillis: Long, val value: Float)

fun computeNetWorthOverTime(transactions: List<Transaction>): List<DateValuePoint> {
    if (transactions.isEmpty()) return emptyList()
    val sorted = transactions.sortedBy { it.toDateLong() }
    var total = 0f
    val results = mutableListOf<DateValuePoint>()
    for (txn in sorted) {
        total += txn.amount.toFloat()
        results.add(DateValuePoint(txn.toDateLong(), total))
    }
    return results
}

@Composable
fun NetWorthSection(
    textStyle: TextStyle,
    filteredTransactions: List<Transaction>
) {
    val netWorthData = remember(filteredTransactions) {
        computeNetWorthOverTime(filteredTransactions)
    }

    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Net Worth", style = textStyle.copy(fontSize = 20.sp), color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            if (netWorthData.isEmpty()) {
                Text("No net worth data yet. Add transactions to see changes over time.", style = textStyle)
            } else {
                Text("Changes over time", style = textStyle)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    MPAndroidLineChartReal(netWorthData)
                }
            }
        }
    }
}

@SuppressLint("NewApi")
@Composable
fun MPAndroidLineChartReal(netWorthData: List<DateValuePoint>) {
    val context = LocalContext.current
    AndroidView(
        factory = {
            LineChart(context).apply {
                description.isEnabled = false
                setPinchZoom(false)
                axisLeft.setDrawGridLines(false)
                xAxis.setDrawGridLines(false)
            }
        },
        update = update@{ lineChart ->
            if (netWorthData.isEmpty()) {
                lineChart.data = null
                lineChart.invalidate()
                return@update
            }

            val entries = netWorthData.mapIndexed { index, dvp ->
                Entry(index.toFloat(), dvp.value)
            }

            val dataSet = LineDataSet(entries, "Net Worth").apply {
                color = ColorTemplate.rgb("#512DA8")
                lineWidth = 3f
                setCircleColor(ColorTemplate.rgb("#512DA8"))
                circleRadius = 4f
            }
            val lineData = LineData(dataSet)
            lineChart.data = lineData
            lineChart.invalidate()
        },
        modifier = Modifier.fillMaxSize()
    )
}

//-------------------------------------
//  FinancialGoalsSection
//-------------------------------------
@Composable
fun FinancialGoalsSection(
    textStyle: TextStyle,
    goals: List<Goal>,
    onAddProgress: (Goal, Double) -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Financial Goals", style = textStyle.copy(fontSize = 20.sp), color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))

            if (goals.isEmpty()) {
                Text("No goals found. Add one below!", style = textStyle)
            } else {
                goals.forEach { g ->
                    Spacer(Modifier.height(8.dp))
                    GoalRow(g, textStyle, onAddProgress)
                }
            }
        }
    }
}

@Composable
fun GoalRow(
    goal: Goal,
    textStyle: TextStyle,
    onAddProgress: (Goal, Double) -> Unit
) {
    Card(
        shape = RoundedCornerShape(6.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(goal.title, style = textStyle.copy(fontSize = 18.sp))
            val fraction = if (goal.targetAmount == 0.0) 0f else (goal.currentAmount / goal.targetAmount).toFloat()
            LinearProgressIndicator(fraction.coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth())
            Text("€%.2f / €%.2f".format(goal.currentAmount, goal.targetAmount), style = textStyle)

            OutlinedButton(onClick = {
                // Example: add 10 to the current progress
                onAddProgress(goal, 10.0)
            }) {
                Text("Add €10", style = textStyle)
            }
        }
    }
}

//-------------------------------------
// BudgetingSection placeholder
//-------------------------------------
@Composable
fun BudgetingSection(
    navController: NavController,
    textStyle: TextStyle
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Budgeting", style = textStyle.copy(fontSize = 20.sp), color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text("Monthly leftover, daily leftover, etc.", style = textStyle)
            Spacer(Modifier.height(8.dp))

            Text("• €750 left to spend this month", style = textStyle)
            Text("• That's €25/day for the rest of the month", style = textStyle)

            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = {
                // Navigate to the new detailed screen
                navController.navigate("detailed_budget")
            }) {
                Text("View Detailed Budget", style = textStyle)
            }
        }
    }
}


//-------------------------------------
//  MonthlySpendingBoxes
//-------------------------------------
@Composable
fun MonthlySpendingBoxes(
    allTxns: List<Transaction>,
    textStyle: TextStyle
) {
    val monthlyMap = allTxns.groupBy { it.toYearMonthString() }.mapValues { it.value.sumOf { t -> t.amount } }
    val negativeTxns = allTxns.filter { it.amount < 0.0 }
    val categoryMap = negativeTxns.groupBy { it.category }.mapValues { it.value.sumOf { t -> t.amount } }
    val largestSpendingAreas = categoryMap.entries.sortedBy { it.value }
    val topThreeSpending = largestSpendingAreas.take(3)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Monthly Spending Summary:", style = textStyle.copy(fontSize = 18.sp))
            Spacer(modifier = Modifier.height(8.dp))

            if (allTxns.isEmpty()) {
                Text("No transactions found to summarize.", style = textStyle)
            } else {
                monthlyMap.toSortedMap().forEach { (month, sum) ->
                    Text("$month : €%.2f".format(sum), style = textStyle)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("Biggest Spending Areas:", style = textStyle)
                if (topThreeSpending.isEmpty()) {
                    Text("No negative transactions found", style = textStyle)
                } else {
                    topThreeSpending.forEach { (cat, total) ->
                        Text("- $cat : €%.2f".format(total), style = textStyle)
                    }
                }
            }
        }
    }
}

//-------------------------------------
//  TransactionListSection
//-------------------------------------
@Composable
fun TransactionListSection(
    textStyle: TextStyle,
    filteredTransactions: List<Transaction>,
    shownCount: Int,
    expandedTransactionId: String?,
    onExpandToggle: (String) -> Unit,
    onShowMore: () -> Unit,
    onDeleteTxn: (Transaction) -> Unit,
    onEditTxn: (Transaction) -> Unit,
    onCategoryChange: (Transaction, String) -> Unit
) {
    val sortedByDate = filteredTransactions.sortedByDescending { it.toDateLong() }
    val displayedTransactions = if (sortedByDate.size > shownCount) {
        sortedByDate.take(shownCount)
    } else {
        sortedByDate
    }

    Text("Recent Transactions:", style = textStyle.copy(fontSize = 20.sp))
    Spacer(modifier = Modifier.height(8.dp))

    if (filteredTransactions.isEmpty()) {
        Text("No transactions found to display here.", style = textStyle)
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        displayedTransactions.forEach { txn ->
            TransactionRowWithExpand(
                txn = txn,
                textStyle = textStyle,
                isExpanded = (expandedTransactionId == txn.id),
                onExpandToggle = { onExpandToggle(txn.id) },
                onDelete = onDeleteTxn,
                onEdit = onEditTxn,
                onCategoryChange = onCategoryChange
            )
        }

        if (sortedByDate.size > displayedTransactions.size) {
            OutlinedButton(onClick = onShowMore) {
                Text("Show More", style = textStyle)
            }
        }
    }
}

//-------------------------------------
//  TransactionRowWithExpand
//-------------------------------------
@Composable
fun TransactionRowWithExpand(
    txn: Transaction,
    textStyle: TextStyle,
    isExpanded: Boolean,
    onExpandToggle: () -> Unit,
    onDelete: (Transaction) -> Unit,
    onEdit: (Transaction) -> Unit,
    onCategoryChange: (Transaction, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onExpandToggle() }
            .padding(8.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text(txn.date ?: "", style = textStyle)
                Text(txn.details ?: "", style = textStyle)
            }
            Text("€%.2f".format(txn.amount), style = textStyle)
        }

        if (isExpanded) {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Category: ${txn.category}", style = textStyle)

            Row {
                OutlinedButton(onClick = { onEdit(txn) }) {
                    Text("Edit", style = textStyle)
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(onClick = { onDelete(txn) }) {
                    Text("Delete", style = textStyle)
                }
            }

            val categories = listOf("Home", "Entertainment", "Food", "Travel", "Uncategorized")
            var showCatDialog by remember { mutableStateOf(false) }

            OutlinedButton(onClick = { showCatDialog = true }) {
                Text("Change Category", style = textStyle)
            }

            if (showCatDialog) {
                AlertDialog(
                    onDismissRequest = { showCatDialog = false },
                    title = { Text("Select Category", style = textStyle) },
                    text = {
                        Column {
                            categories.forEach { cat ->
                                OutlinedButton(onClick = {
                                    onCategoryChange(txn, cat)
                                    showCatDialog = false
                                }) {
                                    Text(cat, style = textStyle)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        OutlinedButton(onClick = { showCatDialog = false }) {
                            Text("Cancel", style = textStyle)
                        }
                    }
                )
            }
        }
    }
}

//-------------------------------------
//  MPAndroidPieChart
//-------------------------------------
@SuppressLint("NewApi")
@Composable
fun MPAndroidPieChart(
    income: Float,
    expenses: Float
) {
    val context = LocalContext.current
    AndroidView(
        factory = {
            PieChart(context).apply {
                description.isEnabled = false
                setUsePercentValues(false)
                setDrawEntryLabels(true)
                holeRadius = 40f
            }
        },
        update = { pieChart ->
            val entries = mutableListOf<PieEntry>()
            if (income > 0f) entries.add(PieEntry(income, "Income"))
            if (expenses > 0f) entries.add(PieEntry(expenses, "Expenses"))

            val dataSet = PieDataSet(entries, "Budget")
            dataSet.colors = listOf(
                ColorTemplate.rgb("#2E7D32"), // green
                ColorTemplate.rgb("#C62828")  // red
            )
            dataSet.sliceSpace = 3f

            val data = PieData(dataSet)
            data.setValueTextSize(14f)
            pieChart.data = data
            pieChart.invalidate()
        },
        modifier = Modifier.fillMaxSize()
    )
}

//-------------------------------------
//  GOAL DIALOG: user enters Title + Target
//-------------------------------------
@Composable
fun AddGoalDialog(
    onDismiss: () -> Unit,
    onAddGoal: (String, Double) -> Unit,
    textStyle: TextStyle
) {
    var goalTitle by remember { mutableStateOf("") }
    var goalTarget by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a New Goal", style = textStyle) },
        text = {
            Column {
                Text("Enter your goal title:", style = textStyle)
                Spacer(Modifier.height(8.dp))
                BasicTextField(
                    value = goalTitle,
                    onValueChange = { goalTitle = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.LightGray)
                        .padding(8.dp),
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Text)
                )

                Spacer(Modifier.height(16.dp))
                Text("Target Amount (€):", style = textStyle)
                Spacer(Modifier.height(8.dp))
                BasicTextField(
                    value = goalTarget,
                    onValueChange = { goalTarget = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.LightGray)
                        .padding(8.dp),
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            OutlinedButton(onClick = {
                val targetVal = goalTarget.toDoubleOrNull() ?: 0.0
                if (goalTitle.isNotEmpty()) {
                    onAddGoal(goalTitle, targetVal)
                }
                onDismiss()
            }) {
                Text("Add Goal", style = textStyle)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", style = textStyle)
            }
        }
    )
}

//-------------------------------------
// HELPER: filter logic
//-------------------------------------
fun filterTransactions(transactions: List<Transaction>, range: String): List<Transaction> {
    val sdf = SimpleDateFormat("d MMM yyyy", Locale.US)
    val calendar = Calendar.getInstance()

    when (range) {
        "1M" -> calendar.add(Calendar.MONTH, -1)
        "3M" -> calendar.add(Calendar.MONTH, -3)
        "6M" -> calendar.add(Calendar.MONTH, -6)
        "1Y" -> calendar.add(Calendar.YEAR, -1)
    }
    val cutoff = calendar.time

    if (range == "ALL") {
        return transactions
    }

    return transactions.filter { txn ->
        txn.date?.let {
            try {
                val txnDate = sdf.parse(it)
                txnDate?.after(cutoff) == true
            } catch (e: Exception) {
                false
            }
        } ?: false
    }
}

fun Transaction.toDateLong(): Long {
    val sdf = SimpleDateFormat("d MMM yyyy", Locale.US)
    return try {
        sdf.parse(this.date ?: "")?.time ?: 0
    } catch (e: Exception) {
        0
    }
}

fun Transaction.toYearMonthString(): String {
    val sdf = SimpleDateFormat("d MMM yyyy", Locale.US)
    return try {
        val dateObj = sdf.parse(this.date ?: "")
        val out = SimpleDateFormat("yyyy-MM", Locale.US)
        out.format(dateObj ?: Date(0))
    } catch (e: Exception) {
        "unknown"
    }
}
