package com.example.save4u.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.save4u.network.RetrofitClient
import com.example.save4u.network.UploadResponse
import com.google.firebase.auth.FirebaseAuth
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@Composable
fun UploadStatementScreen() {
    var selectedPdfUri by remember { mutableStateOf<Uri?>(null) }
    var statusMessage by remember { mutableStateOf("") }

    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()

    // PDF picker launcher
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri: Uri? ->
            uri?.let {
                selectedPdfUri = it
                statusMessage = "PDF selected: $it"
            }
        }
    )

    fun uploadPdfToBackend(uri: Uri) {
        val currentUserId = auth.currentUser?.uid
        if (currentUserId == null) {
            statusMessage = "Error: No user is logged in."
            return
        }

        val inputStream = context.contentResolver.openInputStream(uri) ?: return
        val bytes = inputStream.readBytes()

        // Create the multipart for the PDF
        val requestFile = bytes.toRequestBody("application/pdf".toMediaTypeOrNull())
        val pdfPart = MultipartBody.Part.createFormData(
            "pdf",
            "statement.pdf",
            requestFile
        )

        // Create the request body for the user ID
        val userIdPart: RequestBody = currentUserId.toRequestBody("text/plain".toMediaTypeOrNull())

        // Make the call with both parts
        val call = RetrofitClient.api.uploadPdf(pdfPart, userIdPart)
        call.enqueue(object : Callback<UploadResponse> {
            override fun onResponse(call: Call<UploadResponse>, response: Response<UploadResponse>) {
                if (response.isSuccessful) {
                    val respBody = response.body()
                    respBody?.let {
                        statusMessage = "Upload success: ${it.message}"
                    } ?: run {
                        statusMessage = "Upload success, but empty response"
                    }
                } else {
                    statusMessage = "Server error: ${response.errorBody()?.string()}"
                }
            }

            override fun onFailure(call: Call<UploadResponse>, t: Throwable) {
                statusMessage = "Upload failed: ${t.localizedMessage}"
            }
        })
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column {
            Button(
                onClick = { pdfPickerLauncher.launch(arrayOf("application/pdf")) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Pick PDF")
            }

            Spacer(modifier = Modifier.height(16.dp))

            selectedPdfUri?.let { uri ->
                Button(
                    onClick = { uploadPdfToBackend(uri) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Upload PDF to Django")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = statusMessage)
        }
    }
}
