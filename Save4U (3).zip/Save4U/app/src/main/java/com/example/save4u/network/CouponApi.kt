import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

suspend fun getDealsFromFirebase(userId: String): JSONObject? {
    val client = OkHttpClient()
    val bodyJson = """{"user_id": "$userId"}"""
    val reqBody = bodyJson.toRequestBody("application/json".toMediaTypeOrNull())
    val request = Request.Builder()
        .url("http://YOUR_SERVER_URL/api/find_coupons_from_firebase/")
        .post(reqBody)
        .build()

    val response = withContext(Dispatchers.IO) {
        client.newCall(request).execute()
    }
    if (!response.isSuccessful) {
        println("DEBUG: Response code = ${response.code}")
        val errBody = response.body?.string()
        println("DEBUG: Error body: $errBody")
        return null
    }
    val bodyStr = response.body?.string() ?: return null
    println("DEBUG: Raw JSON from server -> $bodyStr") // Print for debugging
    return JSONObject(bodyStr)
}
