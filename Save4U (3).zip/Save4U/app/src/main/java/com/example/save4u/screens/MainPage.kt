package com.example.save4u.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

@Composable
fun MainPage(username: String, fontSize: Float, fontStyle: FontFamily) {
    val facts = listOf(
        "Did you know? Tracking expenses can help you save 10% more!",
        "Fun Fact: Setting goals can increase your savings by 20%.",
        "Tip: Reviewing your monthly spending helps curb unnecessary costs.",
        "Did you know? Budgeting can improve financial stability by 30%!"
    )
    val randomFact = facts[Random.nextInt(facts.size)]

    Surface(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Welcome, $username!",
                fontSize = fontSize.sp,
                fontFamily = fontStyle
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = randomFact,
                fontSize = fontSize.sp,
                fontFamily = fontStyle
            )
        }
    }
}
