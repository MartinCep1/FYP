package com.example.save4u.screens

import com.google.firebase.firestore.FirebaseFirestore

fun createUserProfile(userId: String, email: String, username: String) {
    val db = FirebaseFirestore.getInstance()
    val user = hashMapOf(
        "email" to email,
        "username" to username
    )

    db.collection("users").document(userId)
        .set(user)
        .addOnSuccessListener {
        }
        .addOnFailureListener {
        }
}
