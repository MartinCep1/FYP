package com.example.save4u.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlin.random.Random

@Composable
fun BudgetingPage(
    navController: NavController,
    textStyle: TextStyle
) {
    var showDialog by remember { mutableStateOf(false) }
    var customGoals by remember { mutableStateOf(listOf<String>()) }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(text = "Budgeting Plans", style = textStyle.copy(fontSize = 26.sp), color = MaterialTheme.colorScheme.primary)

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { RecommendationSection(textStyle) }
                item { GoalSection(customGoals, textStyle) }
                item { FactSection(textStyle) }

                item {
                    Button(onClick = { showDialog = true }) {
                        Text("Add a New Goal", style = textStyle)
                    }
                }
            }
        }
    }

    if (showDialog) {
        AddGoalDialog(onDismiss = { showDialog = false }, onAddGoal = { customGoals = customGoals + it }, textStyle = textStyle)
    }
}

@Composable
fun RecommendationSection(textStyle: TextStyle) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Recommendations", style = textStyle.copy(fontSize = 20.sp), color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Text("\u2022 Track expenses weekly to identify unnecessary costs.", style = textStyle)
            Text("\u2022 Allocate 20% of your income towards savings.", style = textStyle)
            Text("\u2022 Set up a separate account for long-term goals.", style = textStyle)
        }
    }
}

@Composable
fun GoalSection(customGoals: List<String>, textStyle: TextStyle) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Your Goals", style = textStyle.copy(fontSize = 20.sp), color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Text("\u2022 Save $500 for an emergency fund by the end of the year.", style = textStyle)
            Text("\u2022 Allocate $100 per month towards a vacation fund.", style = textStyle)
            Text("\u2022 Reduce monthly dining expenses by 15%.", style = textStyle)

            if (customGoals.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Custom Goals:", style = textStyle.copy(fontSize = 18.sp), color = MaterialTheme.colorScheme.primary)
                customGoals.forEach { goal ->
                    Text("\u2022 $goal", style = textStyle)
                }
            }
        }
    }
}

@Composable
fun FactSection(textStyle: TextStyle) {
    val facts = listOf(
        "Did you know? Saving $100 each month can result in $1,200 by the end of the year!",
        "Fun Fact: Reducing your coffee spending by $3 daily can save over $1,000 annually.",
        "Budget Tip: Automating savings can increase your total saved amount by 25%!",
        "Smart Choice: Investing early can lead to a 30% increase in your future savings."
    )
    val randomFact = facts[Random.nextInt(facts.size)]

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFBB86FC).copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Did You Know?", style = textStyle.copy(fontSize = 20.sp), color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Text(randomFact, style = textStyle, color = Color.Gray)
        }
    }
}

@Composable
fun AddGoalDialog(onDismiss: () -> Unit, onAddGoal: (String) -> Unit, textStyle: TextStyle) {
    var goalText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a New Goal", style = textStyle) },
        text = {
            Column {
                Text("Enter your goal below:", style = textStyle)
                Spacer(modifier = Modifier.height(8.dp))
                BasicTextField(
                    value = goalText,
                    onValueChange = { goalText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .background(Color.LightGray, RoundedCornerShape(4.dp))
                        .padding(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                )
            }
        },
        confirmButton = {
            Button(onClick = { if (goalText.isNotEmpty()) onAddGoal(goalText) }) {
                Text("Add Goal", style = textStyle)
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel", style = textStyle)
            }
        }
    )
}