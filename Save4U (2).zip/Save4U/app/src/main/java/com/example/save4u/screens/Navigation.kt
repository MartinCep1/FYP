package com.example.save4u.navigation

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Menu
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import com.example.save4u.screens.*
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector

@Composable
fun Navigation(
    navController: NavHostController,
    onThemeChange: (Boolean) -> Unit,
    onPrimaryColorChange: (Color) -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onFontStyleChange: (FontFamily) -> Unit,
    onUsernameChange: (String) -> Unit,
    username: String,
    fontSize: Float,
    fontStyle: FontFamily
) {
    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginPage(
                navController = navController,
                fontSize = fontSize,
                fontStyle = fontStyle
            )
        }
        composable("register") {
            RegisterPage(
                navController = navController,
                fontSize = fontSize,
                fontStyle = fontStyle
            )
        }
        composable("main") {
            MainPage(
                username = username,
                fontSize = fontSize,
                fontStyle = fontStyle
            )
        }
        composable("statistics") {
            StatisticsPage(
                navController = navController,
                fontSize = fontSize,
                fontStyle = fontStyle
            )
        }
        composable("ai_recommendations") {
            AIRecommendationsPage(
                navController = navController,
                textStyle = TextStyle(fontSize = fontSize.sp, fontFamily = fontStyle)
            )
        }
        composable("user") {
            UserPage(
                navController = navController,
                onThemeChange = onThemeChange,
                onPrimaryColorChange = onPrimaryColorChange,
                onFontSizeChange = onFontSizeChange,
                onFontStyleChange = onFontStyleChange,
                onUsernameChange = onUsernameChange,
                currentUsername = username,
                fontSize = fontSize,
                fontStyle = fontStyle
            )
        }
        composable("budgeting") {
            BudgetingPage(
                navController = navController,
                textStyle = TextStyle(fontSize = fontSize.sp, fontFamily = fontStyle)
            )
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    val items = listOf(
        BottomNavItem("Home", "main", Icons.Filled.Home),
        BottomNavItem("Statistics", "statistics", Icons.Filled.Menu),
        BottomNavItem("AI", "ai_recommendations", Icons.Filled.Settings),
        BottomNavItem("User", "user", Icons.Filled.Person),
        BottomNavItem("Budgeting", "budgeting", Icons.Filled.List)
    )

    NavigationBar {
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route
        items.forEach { item ->
            NavigationBarItem(
                icon = { Icon(imageVector = item.icon, contentDescription = item.title) },
                label = { Text(text = item.title) },
                selected = currentRoute == item.route,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.startDestinationId) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

data class BottomNavItem(
    val title: String,
    val route: String,
    val icon: ImageVector
)