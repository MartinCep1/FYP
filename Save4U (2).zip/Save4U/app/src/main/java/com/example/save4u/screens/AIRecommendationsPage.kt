package com.example.save4u.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlin.random.Random

@Composable
fun AIRecommendationsPage(navController: NavController, textStyle: TextStyle) {
    val recommendations = listOf(
        "10% off on groceries at Store A",
        "15% cashback on your next purchase at Store B",
        "Save $50 on your subscription renewal with Service C"
    )
    val randomRecommendation = recommendations[Random.nextInt(recommendations.size)]

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text("AI Recommendations", style = textStyle.copy(fontSize = textStyle.fontSize.times(1.25)))
            Spacer(modifier = Modifier.height(16.dp))
            Text(randomRecommendation, style = textStyle)

            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { /* Apply Recommendation Logic */ }) {
                Text("Apply Recommendation", style = textStyle)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { /* Access Deal Logic */ }) {
                Text("Access Deal", style = textStyle)
            }
        }
    }
}