import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.navigation.compose.rememberNavController
import com.example.save4u.navigation.BottomNavigationBar
import com.example.save4u.navigation.Navigation
import com.example.save4u.ui.theme.Save4UTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val auth = FirebaseAuth.getInstance()
            var isDarkTheme by remember { mutableStateOf(true) }
            var primaryColor by remember { mutableStateOf(Color(0xFF6200EA)) }
            var fontSize by remember { mutableStateOf(16f) }
            var fontStyle by remember { mutableStateOf(FontFamily.SansSerif as FontFamily) }
            var username by remember { mutableStateOf("User") }

            val db = FirebaseFirestore.getInstance()

            // Fetch the username from Firestore when logged in
            LaunchedEffect(auth.currentUser) {
                auth.currentUser?.let { user ->
                    db.collection("users").document(user.uid).get()
                        .addOnSuccessListener { document ->
                            if (document != null && document.contains("username")) {
                                username = document.getString("username") ?: "User"
                            } else {
                                username = user.email?.split("@")?.getOrNull(0) ?: "User"
                            }
                        }
                }
            }

            Save4UTheme(darkTheme = isDarkTheme, primaryColor = primaryColor) {
                val navController = rememberNavController()

                // Check if user is already logged in and navigate accordingly
                LaunchedEffect(Unit) {
                    if (auth.currentUser == null) {
                        navController.navigate("login") {
                            popUpTo(navController.graph.startDestinationId) { inclusive = true }
                        }
                    } else {
                        navController.navigate("main") {
                            popUpTo(navController.graph.startDestinationId) { inclusive = true }
                        }
                    }
                }

                Scaffold(
                    bottomBar = {
                        if (auth.currentUser != null) {
                            BottomNavigationBar(navController)
                        }
                    }
                ) { innerPadding ->
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (auth.currentUser != null) {
                            Navigation(
                                navController = navController,
                                onThemeChange = { isDarkTheme = it },
                                onPrimaryColorChange = { primaryColor = it },
                                onFontSizeChange = { fontSize = it },
                                onFontStyleChange = { fontStyle = it },
                                onUsernameChange = { username = it },
                                username = username,
                                fontSize = fontSize,
                                fontStyle = fontStyle
                            )
                        }
                    }
                }
            }
        }
    }
}