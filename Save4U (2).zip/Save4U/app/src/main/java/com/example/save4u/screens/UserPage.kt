package com.example.save4u.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.graphics.Shape
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun UserPage(
    navController: NavController,
    onThemeChange: (Boolean) -> Unit,
    onPrimaryColorChange: (Color) -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onFontStyleChange: (FontFamily) -> Unit,
    onUsernameChange: (String) -> Unit,
    currentUsername: String,
    fontSize: Float,
    fontStyle: FontFamily
) {
    val auth = FirebaseAuth.getInstance()
    var isDarkTheme by remember { mutableStateOf(true) }
    var selectedPrimaryColor by remember { mutableStateOf(Color(0xFF6200EA)) }
    var username by remember { mutableStateOf(currentUsername) }
    var expanded by remember { mutableStateOf(false) }

    LaunchedEffect(isDarkTheme) {
        onThemeChange(isDarkTheme)
    }

    val fontFamilies = listOf("SansSerif", "Serif", "Monospace", "Cursive")
    val fontFamilyMap = mapOf(
        "SansSerif" to FontFamily.SansSerif,
        "Serif" to FontFamily.Serif,
        "Monospace" to FontFamily.Monospace,
        "Cursive" to FontFamily.Cursive
    )

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Welcome, $username!",
                fontSize = (fontSize + 4).sp,
                fontFamily = fontStyle,
                color = MaterialTheme.colorScheme.primary
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Dark Theme", fontSize = fontSize.sp, fontFamily = fontStyle)
                Spacer(modifier = Modifier.weight(1f))
                CustomButton(
                    onClick = {
                        isDarkTheme = !isDarkTheme
                        onThemeChange(isDarkTheme)
                    },
                    text = if (isDarkTheme) "ON" else "OFF",
                    modifier = Modifier.size(48.dp),
                    backgroundColor = if (isDarkTheme) Color.Black else Color.LightGray,
                    contentColor = Color.White
                )
            }

            Text("Primary Color", fontSize = fontSize.sp, fontFamily = fontStyle)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(Color(0xFF6200EA), Color(0xFFFF5722), Color(0xFF4CAF50), Color(0xFF2196F3)).forEach { color ->
                    CustomButton(
                        onClick = {
                            selectedPrimaryColor = color
                            onPrimaryColorChange(color)
                        },
                        text = "",
                        modifier = Modifier.size(48.dp),
                        backgroundColor = color
                    )
                }
            }

            Text("Font Size", fontSize = fontSize.sp, fontFamily = fontStyle)
            Slider(
                value = fontSize,
                onValueChange = { onFontSizeChange(it) },
                valueRange = 12f..30f
            )

            Text("Font Style", fontSize = fontSize.sp, fontFamily = fontStyle)
            Box {
                CustomButton(onClick = { expanded = true }, text = fontFamilies.find { fontFamilyMap[it] == fontStyle } ?: "SansSerif")
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    fontFamilies.forEach { font ->
                        DropdownMenuItem(
                            text = { Text(font) },
                            onClick = {
                                onFontStyleChange(fontFamilyMap[font] ?: FontFamily.SansSerif)
                                expanded = false
                            }
                        )
                    }
                }
            }

            CustomButton(
                onClick = {
                    auth.signOut()
                    navController.navigate("login") {
                        popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    }
                },
                text = "Sign Out",
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
